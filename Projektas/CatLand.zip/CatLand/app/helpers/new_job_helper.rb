module NewJobHelper
end
