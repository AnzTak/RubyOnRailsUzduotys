module ResHelper
end
