class User_contact < ActiveRecord::Base
end