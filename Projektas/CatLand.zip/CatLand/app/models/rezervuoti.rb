class Rezervuoti < ActiveRecord::Base
end