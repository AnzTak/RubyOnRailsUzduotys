class ResController < ApplicationController
end
